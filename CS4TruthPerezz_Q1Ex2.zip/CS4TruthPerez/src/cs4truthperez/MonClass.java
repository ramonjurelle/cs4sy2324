/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cs4truthperez;

/**
 *
 * @author Super
 */
public class MonClass {
     String genshinCharac;
     int characAge;
     double burstCD;
     
    public void changeGenshinCharac (String getGenshinCharac){
        this.genshinCharac = getGenshinCharac;
    }
        
    public void changeCharacAge (int getCharacAge){
        this.characAge = getCharacAge;
    }
        
    public void changeburstCD (double getburstCD){
        this.burstCD = getburstCD;
    }
}