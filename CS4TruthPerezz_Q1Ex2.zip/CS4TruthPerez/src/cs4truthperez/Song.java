/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cs4truthperez;

/**
 *
 * @author Super
 */
public class Song {
    String songName;
    String artistName;
    double songLength;
    
    public void giveSongName (String giveSongName){
        this.songName = giveSongName;
    }
    
    public void giveArtistName (String giveArtistName){
        this.artistName = giveArtistName;
    }
    
    public void giveSongLength (double giveSongLength){
        this.songLength = giveSongLength;
    }
}
