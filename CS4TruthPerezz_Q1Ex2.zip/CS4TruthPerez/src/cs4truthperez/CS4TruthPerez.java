/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cs4truthperez;

/**
 *
 * @author Super
 */
public class CS4TruthPerez {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        MonClass info = new MonClass();
        info.changeGenshinCharac("Kamisato Ayaka");
        info.changeCharacAge(20);
        info.changeburstCD(10.0);
        System.out.println(info.genshinCharac);
        System.out.println(info.characAge);
        System.out.println(info.burstCD);
        
        
        Song a = new Song();
        a.giveSongName("Unexpectedly");
        System.out.println(a.songName);   
        a.giveArtistName("Megumi Acorda");
        System.out.println(a.artistName); 
        a.giveSongLength(4.4);
        System.out.println(a.songLength); 
        
        Singer setSinger = new Singer();
        setSinger.favoriteSong = a;
        setSinger.performForAudience(12);
        System.out.println("no. of Perofrmances: " + setSinger.noOfPerformances);
        System.out.println("Earnings: " + setSinger.earnings + " PhP");
        System.out.println("New Song:  " + setSinger.favoriteSong.songName); 
    }
    
}
