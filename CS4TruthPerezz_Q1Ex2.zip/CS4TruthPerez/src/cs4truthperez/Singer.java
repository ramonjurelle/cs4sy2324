/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cs4truthperez;

/**
 *
 * @author Super
 */
public class Singer {
    String name;
    int noOfPerformances;
    double earnings;
    Song favoriteSong;
    
    public void performForAudience(int perf) {
        this.noOfPerformances = perf;
        this.earnings = earnings + perf * 100;
    }
    public void changeFavSong(Song newSong){
        this.favoriteSong = newSong;
    }
}

    
